package com.example.androidnativegrupo5;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        // Enlazamos las vistas
        TextView tvNombre = findViewById(R.id.tvDetailNombre);
        TextView tvDesc = findViewById(R.id.tvDetailDesc);
        TextView tvPrecio = findViewById(R.id.tvDetailPrecio);
        TextView tvPunto = findViewById(R.id.tvDetailPunto);
        TextView tvGuia = findViewById(R.id.tvDetailGuia);

        // Recuperamos los datos que nos mandó la HomeActivity a través del Intent
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String nombre = extras.getString("NOMBRE");
            String descripcion = extras.getString("DESCRIPCION");
            double precio = extras.getDouble("PRECIO", 0.0);
            String punto = extras.getString("PUNTO_ENCUENTRO");
            String guia = extras.getString("GUIA");

            // Metemos los datos en la pantalla
            tvNombre.setText(nombre);
            tvDesc.setText("Descripción: " + descripcion);
            tvPrecio.setText("Precio total: €" + precio);
            tvPunto.setText("📍 Punto de encuentro: " + punto);
            tvGuia.setText("👤 Tu guía será: " + guia);
        }
    }
}
