package com.example.androidnativegrupo5;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        ListView lvActividades = findViewById(R.id.lvActividades);

        // 1. Creamos datos de prueba (Mock)
        List<Actividad> lista = new ArrayList<>();
        lista.add(new Actividad("Visita Guiada al Teide", "Tenerife", "Excursión", "4 horas", 45.0, 10, "Subida en teleférico y caminata.", "Guía y tickets", "Base del teleférico", "Carlos", "Español", "Reembolso 48hs antes"));
        lista.add(new Actividad("Free Tour Madrid Central", "Madrid", "Free Tour", "2 horas", 0.0, 25, "Recorrido histórico por la capital.", "No incluye comida", "Puerta del Sol", "Ana", "Español/Inglés", "Sin cargo"));
        lista.add(new Actividad("Ruta Gastronómica", "Buenos Aires", "Gastronomía", "3 horas", 30.0, 8, "Cata de vinos y empanadas.", "Comida y bebida", "Plaza Serrano", "Marcos", "Español", "No cancelable"));

        // 2. Conectamos la lista con el Adapter
        ActividadAdapter adapter = new ActividadAdapter(this, lista);
        lvActividades.setAdapter(adapter);

        // 3. Magia de Navegación: Al hacer clic en un ítem, pasamos los datos
        lvActividades.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Actividad seleccionada = lista.get(position);

                Intent intent = new Intent(HomeActivity.this, DetailActivity.class);
                intent.putExtra("NOMBRE", seleccionada.getNombre());
                intent.putExtra("DESCRIPCION", seleccionada.getDescripcion());
                intent.putExtra("PRECIO", seleccionada.getPrecio());
                intent.putExtra("PUNTO_ENCUENTRO", seleccionada.getPuntoEncuentro());
                intent.putExtra("GUIA", seleccionada.getGuia());
                // Podés seguir agregando putExtra para el resto de los datos...

                startActivity(intent);
            }
        });
    }
}