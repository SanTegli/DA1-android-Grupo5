package com.example.androidnativegrupo5;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.List;

public class ActividadAdapter extends ArrayAdapter<Actividad> {

    public ActividadAdapter(Context context, List<Actividad> actividades) {
        super(context, 0, actividades);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_actividad, parent, false);
        }

        Actividad actividad = getItem(position);

        TextView tvNombre = convertView.findViewById(R.id.tvNombreFila);
        TextView tvDestino = convertView.findViewById(R.id.tvDestinoFila);
        TextView tvPrecio = convertView.findViewById(R.id.tvPrecioFila);

        tvNombre.setText(actividad.getNombre());
        tvDestino.setText(actividad.getDestino() + " - " + actividad.getCategoria());
        tvPrecio.setText("Precio: €" + actividad.getPrecio() + " (" + actividad.getCupos() + " cupos)");

        return convertView;
    }
}