package com.example.androidnativegrupo5;

public class Actividad {
    // Atributos que pide el TPO
    private String nombre;
    private String destino;
    private String categoria;
    private String duracion;
    private double precio;
    private int cupos;
    private String descripcion;
    private String incluye;
    private String puntoEncuentro;
    private String guia;
    private String idioma;
    private String politicaCancelacion;

    // Constructor completo (Alt+Insert > Constructor para generarlo rápido en el futuro)
    public Actividad(String nombre, String destino, String categoria, String duracion, double precio, int cupos, String descripcion, String incluye, String puntoEncuentro, String guia, String idioma, String politicaCancelacion) {
        this.nombre = nombre; this.destino = destino; this.categoria = categoria; this.duracion = duracion;
        this.precio = precio; this.cupos = cupos; this.descripcion = descripcion; this.incluye = incluye;
        this.puntoEncuentro = puntoEncuentro; this.guia = guia; this.idioma = idioma; this.politicaCancelacion = politicaCancelacion;
    }

    // Getters para leer los datos
    public String getNombre() { return nombre; }
    public String getDestino() { return destino; }
    public String getCategoria() { return categoria; }
    public String getDuracion() { return duracion; }
    public double getPrecio() { return precio; }
    public int getCupos() { return cupos; }
    public String getDescripcion() { return descripcion; }
    public String getIncluye() { return incluye; }
    public String getPuntoEncuentro() { return puntoEncuentro; }
    public String getGuia() { return guia; }
    public String getIdioma() { return idioma; }
    public String getPoliticaCancelacion() { return politicaCancelacion; }
}